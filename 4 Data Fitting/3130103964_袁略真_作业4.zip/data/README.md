# 各数据文件简介
文件名                       |来源                  |存储内容
---------------------------  |----------------------|-----------
result_dataset.txt           |[../src/fitting/main.cpp]|对于每个N的1000行随机产生的数据
result_stat.txt              |[../src/fitting/main.cpp]|数据集的简单统计量
result_transformeddata.txt   |[../src/fitting/main.cpp]|根据选定的拟合模型对原始数据进行适当转换
result_fitting.txt           |[../src/fitting/main.cpp]|线性拟合,给出拟合后的结果(数据转换为原始状态)
