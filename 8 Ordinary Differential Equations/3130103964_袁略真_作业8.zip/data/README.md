# Description
file        |lambda|Va|R|C|L
------------|------|--|-|-|-
result1.txt |0.5   |5 |2|1|4
result2.txt |1     |5 |4|1|4
result3.txt |2     |5 |5|1|4
