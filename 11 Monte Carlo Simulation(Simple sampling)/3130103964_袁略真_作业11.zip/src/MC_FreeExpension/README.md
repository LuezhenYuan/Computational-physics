```
paste -d"\t" result_average_configuration.txt result_configuration_*.txt > result_all_configuration_10.txt
rm result_configuration_*.txt
```
